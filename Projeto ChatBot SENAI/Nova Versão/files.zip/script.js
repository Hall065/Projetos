/**
 * ScoreBot — script.js
 * Versão 2.0 — com:
 *   • Voice Input (Speech Recognition nativo)
 *   • Text-to-Speech (SpeechSynthesis nativo)
 *   • Histórico de chats (localStorage)
 *   • Memória de mensagens via JSON (localStorage)
 *   • 3-dot context menu por mensagem
 *   • Score Advisor — chat especializado pós-análise
 *   • Download de análise em JSON
 */

// ============================================================
// ESTADO GLOBAL
// ============================================================
let sessionId = null;
let userProfileType = null;
let currentStep = 1;
const TOTAL_STEPS = 4;
let lastResultData = null;
let advisorData = null;
let advisorHistory = [];
let ctxTargetMessage = null;

// ============================================================
// MEMORY (localStorage)
// ============================================================
const MEMORY_KEY = 'scorebot_memory';
const HISTORY_KEY = 'scorebot_history';

function getMemory() {
    try { return JSON.parse(localStorage.getItem(MEMORY_KEY) || '[]'); }
    catch { return []; }
}
function saveMemory(items) {
    localStorage.setItem(MEMORY_KEY, JSON.stringify(items));
}
function addToMemory(text, role) {
    const mem = getMemory();
    mem.push({ id: Date.now(), text, role, savedAt: new Date().toISOString() });
    saveMemory(mem);
    showToast('💾 Salvo na memória!');
}
function removeFromMemory(id) {
    const mem = getMemory().filter(m => m.id !== id);
    saveMemory(mem);
    showToast('🗑️ Removido da memória');
}

function getChatHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); }
    catch { return []; }
}
function saveChatHistory(sessions) {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(sessions));
}
function saveCurrentSession(name, profileType, resultData) {
    const sessions = getChatHistory();
    const entry = {
        id: sessionId || Date.now().toString(),
        name: name || 'Análise sem nome',
        profileType,
        score: resultData ? resultData.score : null,
        tier: resultData ? resultData.tier : null,
        date: new Date().toISOString(),
        result: resultData
    };
    // Keep max 10 sessions
    sessions.unshift(entry);
    if (sessions.length > 10) sessions.pop();
    saveChatHistory(sessions);
    renderHistory();
}

function renderHistory() {
    const list = document.getElementById('historyList');
    if (!list) return;
    const sessions = getChatHistory();
    if (sessions.length === 0) {
        list.innerHTML = '<div class="history-empty">Nenhuma análise salva ainda</div>';
        return;
    }
    list.innerHTML = sessions.map(s => {
        const date = new Date(s.date).toLocaleDateString('pt-BR', { day:'2-digit', month:'short', year:'2-digit' });
        const scoreColor = s.score ? scoreTierColor(s.score) : 'var(--text-muted)';
        return `
        <div class="history-item" onclick="loadHistorySession('${s.id}')">
            <div class="hi-left">
                <div class="hi-name">${s.name}</div>
                <div class="hi-meta">${s.profileType === 'pj' ? 'PJ' : 'PF'} · ${date}</div>
            </div>
            ${s.score ? `<div class="hi-score" style="color:${scoreColor}">${s.score}</div>` : ''}
            <button class="hi-del" onclick="deleteHistorySession(event, '${s.id}')" title="Remover">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="12" height="12"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>`;
    }).join('');
}

function loadHistorySession(id) {
    const sessions = getChatHistory();
    const s = sessions.find(x => x.id === id);
    if (!s || !s.result) return;
    userProfileType = s.profileType;
    lastResultData = s.result;
    renderResults(s.result);
    showPage('resultsPage');
}

function deleteHistorySession(e, id) {
    e.stopPropagation();
    const sessions = getChatHistory().filter(s => s.id !== id);
    saveChatHistory(sessions);
    renderHistory();
}

// ============================================================
// MARKDOWN → HTML
// ============================================================
function parseMarkdown(text) {
    text = text.replace(/<br\s*\/?>/gi, '\n');
    text = text.replace(/<\/?(?!strong|em|b|i)[a-z][^>]*>/gi, '');
    text = text.replace(/```[\w]*\n?([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/__(.+?)__/g, '<strong>$1</strong>');
    text = text.replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>');
    text = text.replace(/(?<!_)_(?!_)(.+?)(?<!_)_(?!_)/g, '<em>$1</em>');
    text = text.replace(/^[\s]*[-*]\s+(.+)$/gm, '<li>$1</li>');
    text = text.replace(/(<li>.*<\/li>(\n|$))+/g, match => `<ul>${match}</ul>`);
    text = text.replace(/^[\s]*\d+\.\s+(.+)$/gm, '<li>$1</li>');
    text = text.replace(/^#{3}\s+(.+)$/gm, '<strong class="md-h3">$1</strong>');
    text = text.replace(/^#{2}\s+(.+)$/gm, '<strong class="md-h2">$1</strong>');
    text = text.replace(/^#{1}\s+(.+)$/gm, '<strong class="md-h1">$1</strong>');
    text = text.replace(/^---+$/gm, '<hr class="md-hr">');
    text = text.replace(/\n{2,}/g, '</p><p>');
    text = text.replace(/\n/g, '<br>');
    text = `<p>${text}</p>`;
    text = text.replace(/<p><\/p>/g, '');
    text = text.replace(/<p>\s*<\/p>/g, '');
    return text;
}

// ============================================================
// TOAST
// ============================================================
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2600);
}

// ============================================================
// NAVEGAÇÃO
// ============================================================
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    document.getElementById(pageId).classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    closeCtxMenu();
}

document.getElementById('startBtn').addEventListener('click', () => showPage('profilePage'));
document.getElementById('choosePF').addEventListener('click', () => { userProfileType = 'pf'; setBadge('Pessoa Física'); showPage('chatPage'); startConversation(); });
document.getElementById('choosePJ').addEventListener('click', () => { userProfileType = 'pj'; setBadge('Pessoa Jurídica'); showPage('chatPage'); startConversation(); });
document.getElementById('backFromProfile').addEventListener('click', () => showPage('landingPage'));
document.getElementById('backBtn').addEventListener('click', () => { resetSession(); showPage('profilePage'); });
document.getElementById('novaAnalise').addEventListener('click', () => { resetSession(); showPage('profilePage'); });
document.getElementById('backFromResults').addEventListener('click', () => { resetSession(); showPage('landingPage'); });
document.getElementById('backFromAdvisor').addEventListener('click', () => showPage('resultsPage'));

document.getElementById('openAdvisorBtn').addEventListener('click', () => {
    showPage('advisorPage');
    if (lastResultData) {
        loadAdvisorData(lastResultData);
    }
});

document.getElementById('downloadJsonBtn').addEventListener('click', () => {
    if (!lastResultData) return;
    const blob = new Blob([JSON.stringify(lastResultData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `scorebot_${(lastResultData.nome || 'analise').replace(/\s+/g, '_')}_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('📥 Arquivo JSON baixado!');
});

// ============================================================
// BADGE DE PERFIL
// ============================================================
function setBadge(text) {
    const el = document.getElementById('chatProfileBadge');
    if (el) el.textContent = text;
}

// ============================================================
// PROGRESSO
// ============================================================
function setStep(step) {
    currentStep = step;
    document.querySelectorAll('.ps-step').forEach(el => {
        const n = parseInt(el.dataset.step);
        el.classList.remove('active', 'done');
        if (n === step) el.classList.add('active');
        else if (n < step) el.classList.add('done');
    });
}

// ============================================================
// INICIAR CONVERSA
// ============================================================
async function startConversation() {
    document.getElementById('chatBox').innerHTML = '';
    currentStep = 1;
    setStep(1);
    sessionId = crypto.randomUUID ? crypto.randomUUID() : Date.now().toString();
    const initMsg = userProfileType === 'pj'
        ? 'Olá! Quero fazer uma análise de crédito para minha empresa.'
        : 'Olá! Quero fazer uma análise de crédito pessoal.';
    await sendToBot(initMsg, false);
}

// ============================================================
// ENVIAR MENSAGEM
// ============================================================
async function sendMessage() {
    const input = document.getElementById('userInput');
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    addMessage(text, 'user', 'chatBox');
    await sendToBot(text, false);
}

function handleKeyPress(e) {
    if (e.key === 'Enter') sendMessage();
}

// ============================================================
// SCROLL
// ============================================================
function scrollChatToBottom(boxId = 'chatBox', smooth = true) {
    const chatBox = document.getElementById(boxId);
    if (!chatBox) return;
    chatBox.scrollTo({ top: chatBox.scrollHeight, behavior: smooth ? 'smooth' : 'instant' });
    setTimeout(() => { chatBox.scrollTop = chatBox.scrollHeight; }, 80);
}

// ============================================================
// BACKEND COMM
// ============================================================
async function sendToBot(userText, showUserMsg = true) {
    if (showUserMsg) addMessage(userText, 'user', 'chatBox');
    setInputEnabled(false);
    const typingId = showTyping('chatBox');

    try {
        const res = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: userText, session_id: sessionId, profile_type: userProfileType })
        });
        const data = await res.json();
        removeTyping(typingId);

        if (data.error) { addMessage(data.error, 'bot', 'chatBox'); setInputEnabled(true); return; }
        if (data.session_id) sessionId = data.session_id;

        addMessage(data.response, 'bot', 'chatBox');
        advanceStep(data.response);

        // TTS
        if (document.getElementById('ttsToggle')?.checked) {
            speak(stripHtml(data.response));
        }

        if (data.result_data) {
            lastResultData = data.result_data;
            setStep(4);
            saveCurrentSession(data.result_data.nome, userProfileType, data.result_data);
            setTimeout(() => { renderResults(data.result_data); showPage('resultsPage'); }, 1400);
        } else {
            setInputEnabled(true);
        }
    } catch (err) {
        removeTyping(typingId);
        addMessage('Erro de conexão. Verifique se o servidor Flask está rodando em localhost:5000', 'bot', 'chatBox');
        setInputEnabled(true);
    }
}

function advanceStep(botReply) {
    const r = botReply.toLowerCase();
    if (currentStep === 1 && (r.includes('renda') || r.includes('faturamento') || r.includes('salário'))) setStep(2);
    else if (currentStep === 2 && (r.includes('dívida') || r.includes('histórico') || r.includes('atraso') || r.includes('negativad'))) setStep(3);
    else if (currentStep === 3 && (r.includes('objetivo') || r.includes('finalidade') || r.includes('quer'))) setStep(4);
}

// ============================================================
// MENSAGENS + CONTEXT MENU (3 pontos)
// ============================================================
function addMessage(text, role, boxId = 'chatBox') {
    const chatBox = document.getElementById(boxId);
    const wrapper = document.createElement('div');
    wrapper.className = `msg-wrapper ${role}`;

    const div = document.createElement('div');
    div.className = `message ${role}`;

    if (role === 'bot') {
        div.innerHTML = parseMarkdown(text);
    } else {
        div.textContent = text;
    }

    // 3-dot menu button
    const menuBtn = document.createElement('button');
    menuBtn.className = 'msg-menu-btn';
    menuBtn.title = 'Opções';
    menuBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" width="12" height="12"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>`;
    menuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        ctxTargetMessage = { text: role === 'bot' ? stripHtml(div.innerHTML) : div.textContent, role };
        openCtxMenu(e.clientX, e.clientY);
    });

    wrapper.appendChild(div);
    wrapper.appendChild(menuBtn);
    chatBox.appendChild(wrapper);
    scrollChatToBottom(boxId);
}

function showTyping(boxId = 'chatBox') {
    const chatBox = document.getElementById(boxId);
    const id = 'typing-' + Date.now();
    const wrapper = document.createElement('div');
    wrapper.className = 'msg-wrapper bot';
    wrapper.id = id;
    const div = document.createElement('div');
    div.className = 'message bot typing-indicator';
    div.innerHTML = '<span></span><span></span><span></span>';
    wrapper.appendChild(div);
    chatBox.appendChild(wrapper);
    scrollChatToBottom(boxId);
    return id;
}

function removeTyping(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
}

function setInputEnabled(enabled) {
    const input = document.getElementById('userInput');
    const btn = document.getElementById('sendButton');
    input.disabled = !enabled;
    btn.disabled = !enabled;
    if (enabled) input.focus();
}

// ============================================================
// CONTEXT MENU
// ============================================================
function openCtxMenu(x, y) {
    const menu = document.getElementById('ctxMenu');
    menu.classList.remove('hidden');
    // Posiciona com clamp para não sair da tela
    const mx = Math.min(x, window.innerWidth - 180);
    const my = Math.min(y, window.innerHeight - 120);
    menu.style.left = mx + 'px';
    menu.style.top = my + 'px';
}

function closeCtxMenu() {
    document.getElementById('ctxMenu').classList.add('hidden');
    ctxTargetMessage = null;
}

document.addEventListener('click', closeCtxMenu);
document.getElementById('ctxMenu').addEventListener('click', e => e.stopPropagation());

document.getElementById('ctxSave').addEventListener('click', () => {
    if (!ctxTargetMessage) return;
    addToMemory(ctxTargetMessage.text, ctxTargetMessage.role);
    closeCtxMenu();
});

document.getElementById('ctxCopy').addEventListener('click', () => {
    if (!ctxTargetMessage) return;
    navigator.clipboard.writeText(ctxTargetMessage.text).then(() => showToast('📋 Copiado!'));
    closeCtxMenu();
});

document.getElementById('ctxDelete').addEventListener('click', () => {
    // Remove from memory if saved
    const mem = getMemory();
    const found = mem.find(m => m.text === ctxTargetMessage?.text);
    if (found) removeFromMemory(found.id);
    else showToast('Mensagem não está na memória');
    closeCtxMenu();
});

// ============================================================
// VOICE INPUT — Speech Recognition
// ============================================================
let recognition = null;
let isListening = false;
let recognitionTarget = 'main'; // 'main' | 'advisor'

function initSpeechRecognition() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;
    const r = new SR();
    r.lang = 'pt-BR';
    r.interimResults = true;
    r.maxAlternatives = 1;
    return r;
}

function toggleVoiceInput() {
    recognitionTarget = 'main';
    toggleRecognition('micBtn', 'userInput');
}

function toggleAdvisorVoice() {
    recognitionTarget = 'advisor';
    toggleRecognition('advisorMicBtn', 'advisorInput');
}

function toggleRecognition(btnId, inputId) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { showToast('⚠️ Reconhecimento de voz não suportado neste navegador'); return; }

    const btn = document.getElementById(btnId);

    if (isListening) {
        recognition?.stop();
        setMicState(btn, false);
        isListening = false;
        return;
    }

    recognition = initSpeechRecognition();
    if (!recognition) return;

    const input = document.getElementById(inputId);
    isListening = true;
    setMicState(btn, true);

    recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
            .map(r => r[0].transcript).join('');
        input.value = transcript;

        // Se final, envia automaticamente
        if (event.results[event.results.length - 1].isFinal) {
            recognition.stop();
            setMicState(btn, false);
            isListening = false;
            setTimeout(() => {
                if (recognitionTarget === 'main') sendMessage();
                else sendAdvisorMessage();
            }, 300);
        }
    };

    recognition.onerror = (e) => {
        setMicState(btn, false);
        isListening = false;
        if (e.error !== 'no-speech') showToast('⚠️ Erro no microfone: ' + e.error);
    };

    recognition.onend = () => {
        setMicState(btn, false);
        isListening = false;
    };

    recognition.start();
}

function setMicState(btn, listening) {
    if (!btn) return;
    btn.classList.toggle('mic-active', listening);
}

// ============================================================
// TEXT-TO-SPEECH
// ============================================================
let currentUtterance = null;

function speak(text) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'pt-BR';
    utterance.rate = 1.05;
    utterance.pitch = 1;

    // Prefer a PT-BR voice if available
    const voices = window.speechSynthesis.getVoices();
    const ptVoice = voices.find(v => v.lang.startsWith('pt'));
    if (ptVoice) utterance.voice = ptVoice;

    const status = document.getElementById('ttsStatus');
    if (status) status.textContent = '🔊 falando...';

    utterance.onend = () => { if (status) status.textContent = ''; };
    currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
}

function stripHtml(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
}

// ============================================================
// SCORE ADVISOR
// ============================================================
function loadAdvisorData(data) {
    advisorData = data;
    advisorHistory = [];

    // Show chat area, hide upload zone
    document.getElementById('advisorUploadZone').classList.add('hidden');
    document.getElementById('advisorChatContainer').classList.remove('hidden');

    // Show data banner
    const banner = document.getElementById('advisorDataBanner');
    const scoreColor = scoreTierColor(data.score || 0);
    banner.innerHTML = `
        <div class="adb-score" style="color:${scoreColor}">${data.score || '—'}</div>
        <div class="adb-info">
            <div class="adb-name">${data.nome || 'Usuário'}</div>
            <div class="adb-meta">${data.tier || '—'} · ${data.perfil || ''} · Limite: ${data.limite || '—'}</div>
        </div>
        <div class="adb-tag">${(data.perfil || '').includes('mpresa') ? 'PJ' : 'PF'}</div>
    `;

    // Clear chat & send context to advisor
    document.getElementById('advisorChatBox').innerHTML = '';
    const ctx = `Tenho uma análise de score do ScoreBot. Dados: nome=${data.nome}, score=${data.score}, tier=${data.tier}, renda=${data.renda}, perfil=${data.perfil}, objetivo=${data.objetivo}, limite=${data.limite}. Sugestões recebidas: ${(data.sugestoes || []).map(s => s.titulo).join(', ')}. Quero dicas para melhorar meu score.`;
    sendAdvisorToBot(ctx, false);
}

function loadAdvisorJson(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            loadAdvisorData(data);
        } catch {
            showToast('⚠️ Arquivo JSON inválido');
        }
    };
    reader.readAsText(file);
}

// Drag-and-drop para a advisor upload zone
const uploadZone = document.getElementById('advisorUploadZone');
if (uploadZone) {
    uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.classList.add('drag-over'); });
    uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('drag-over'));
    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('drag-over');
        const file = e.dataTransfer.files[0];
        if (file && file.name.endsWith('.json')) {
            const reader = new FileReader();
            reader.onload = (ev) => {
                try { loadAdvisorData(JSON.parse(ev.target.result)); }
                catch { showToast('⚠️ Arquivo JSON inválido'); }
            };
            reader.readAsText(file);
        } else { showToast('⚠️ Arraste um arquivo .json válido'); }
    });
}

async function sendAdvisorMessage() {
    const input = document.getElementById('advisorInput');
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    addMessage(text, 'user', 'advisorChatBox');
    await sendAdvisorToBot(text, true);
}

function handleAdvisorKeyPress(e) {
    if (e.key === 'Enter') sendAdvisorMessage();
}

async function sendAdvisorToBot(text, addToHistory = true) {
    if (addToHistory) advisorHistory.push({ role: 'user', content: text });

    const btn = document.getElementById('advisorSendBtn');
    const input = document.getElementById('advisorInput');
    if (btn) btn.disabled = true;
    if (input) input.disabled = true;

    const typingId = showTyping('advisorChatBox');

    // Build advisor system prompt with user data context
    const systemPrompt = advisorData ? buildAdvisorSystemPrompt(advisorData) : ADVISOR_SYSTEM_PROMPT_GENERIC;

    try {
        const res = await fetch('/advisor_chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: text,
                history: advisorHistory.slice(-14), // limit context
                system_prompt: systemPrompt
            })
        });

        removeTyping(typingId);

        if (!res.ok) throw new Error('Server error');
        const data = await res.json();
        const reply = data.response || 'Desculpe, não consegui processar sua pergunta.';

        addMessage(reply, 'bot', 'advisorChatBox');
        advisorHistory.push({ role: 'assistant', content: reply });

        if (document.getElementById('advisorTtsToggle')?.checked) {
            speak(stripHtml(reply));
        }
    } catch (err) {
        removeTyping(typingId);
        addMessage('Erro de conexão. Verifique se o servidor Flask está rodando.', 'bot', 'advisorChatBox');
    } finally {
        if (btn) btn.disabled = false;
        if (input) { input.disabled = false; input.focus(); }
    }
}

function buildAdvisorSystemPrompt(data) {
    return `Você é o Score Advisor, especialista em crédito e finanças do ScoreBot.

O usuário tem os seguintes dados de análise de crédito:
- Nome: ${data.nome}
- Score atual: ${data.score} (${data.tier})
- Renda/Faturamento: ${data.renda}
- Perfil: ${data.perfil}
- Objetivo financeiro: ${data.objetivo}
- Limite sugerido: ${data.limite}
- Sugestões já fornecidas: ${(data.sugestoes || []).map(s => s.titulo + ': ' + s.descricao).join(' | ')}

Sua missão: dar dicas práticas, específicas e acionáveis para que este usuário melhore seu score de crédito, com base nos dados acima.

Personalize cada resposta. Seja direto, use linguagem simples, emojis com moderação.
Priorize ações de alto impacto no score. Seja sempre positivo e motivador.
Responda SEMPRE em português brasileiro.`;
}

const ADVISOR_SYSTEM_PROMPT_GENERIC = `Você é o Score Advisor, especialista em crédito e finanças pessoais e empresariais.
Dê dicas práticas para melhorar o score de crédito. Seja direto e use linguagem simples.
Responda SEMPRE em português brasileiro.`;

// ============================================================
// RESULTADOS
// ============================================================
function renderResults(d) {
    document.getElementById('res-nome').textContent = d.nome || 'Usuário';
    document.getElementById('res-score-num').textContent = d.score || '—';

    const tierEl = document.getElementById('res-tier');
    tierEl.textContent = d.tier || '—';
    tierEl.style.color = scoreTierColor(d.score);

    document.getElementById('res-renda').textContent = d.renda || '—';
    document.getElementById('res-perfil').textContent = d.perfil || '—';
    document.getElementById('res-objetivo').textContent = d.objetivo || '—';
    document.getElementById('res-limite').textContent = d.limite || '—';

    const tag = document.getElementById('resProfileTag');
    if (tag) tag.textContent = userProfileType === 'pj' ? 'PJ' : 'PF';

    animateScoreArc(d.score || 0);
    renderSugestoes(d.sugestoes || []);
}

function animateScoreArc(score) {
    const arc = document.getElementById('score-arc-fill');
    const circumference = 2 * Math.PI * 54;
    const pct = Math.min(Math.max(score / 1000, 0), 1);
    arc.style.stroke = scoreTierColor(score);
    setTimeout(() => { arc.style.strokeDasharray = `${pct * circumference} ${circumference}`; }, 400);
}

function scoreTierColor(score) {
    if (score >= 800) return '#2ecc71';
    if (score >= 600) return '#f6e033';
    if (score >= 400) return '#e67e22';
    return '#e74c3c';
}

function renderSugestoes(sugestoes) {
    const grid = document.getElementById('sugestoes-grid');
    grid.innerHTML = '';
    sugestoes.forEach((s, i) => {
        const card = document.createElement('div');
        card.className = 'sug-card' + (s.destaque ? ' sug-destaque' : '');
        card.style.animationDelay = `${i * 0.12}s`;
        card.innerHTML = `
            <div class="sug-icon-wrap">${getSugIcon(s.icone)}</div>
            <div class="sug-body">
                <div class="sug-title">${s.titulo}</div>
                <div class="sug-desc">${s.descricao}</div>
            </div>
            ${s.destaque ? '<div class="sug-badge-dest">Destaque</div>' : ''}
        `;
        grid.appendChild(card);
    });
}

function getSugIcon(emoji) {
    const map = {
        '💳': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="3"/><line x1="2" y1="10" x2="22" y2="10"/></svg>`,
        '📈': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>`,
        '🏦': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
        '🏢': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="2" width="18" height="20" rx="1"/><line x1="9" y1="22" x2="9" y2="12"/><line x1="15" y1="22" x2="15" y2="12"/><rect x="9" y="12" width="6" height="10"/></svg>`,
        '📊': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="2" y1="20" x2="22" y2="20"/></svg>`,
        '💰': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 0 0 0 4h4a2 2 0 0 1 0 4H8"/><line x1="12" y1="6" x2="12" y2="8"/><line x1="12" y1="16" x2="12" y2="18"/></svg>`,
        '💡': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 1 7 7c0 2.38-1.19 4.47-3 5.74V17a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1v-2.26C6.19 13.47 5 11.38 5 9a7 7 0 0 1 7-7z"/></svg>`,
    };
    return map[emoji] || map['💡'];
}

// ============================================================
// RESET
// ============================================================
async function resetSession() {
    if (sessionId) {
        try {
            await fetch('/reset', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: sessionId }) });
        } catch (_) {}
    }
    sessionId = null;
    userProfileType = null;
    currentStep = 1;
    document.getElementById('chatBox').innerHTML = '';
    document.getElementById('chatProfileBadge').textContent = '';
    setStep(1);
    // Stop any TTS
    if (window.speechSynthesis) window.speechSynthesis.cancel();
}

// ============================================================
// TEMA
// ============================================================
const themeCheckbox = document.getElementById('themeCheckbox');
if (themeCheckbox) {
    themeCheckbox.checked = (document.documentElement.getAttribute('data-theme') === 'light');
    themeCheckbox.addEventListener('change', function () {
        document.documentElement.setAttribute('data-theme', this.checked ? 'light' : 'dark');
    });
}

// ============================================================
// DOMContentLoaded — Loading screen, Scroll, History
// ============================================================
document.addEventListener("DOMContentLoaded", () => {
    // Loading screen
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) setTimeout(() => loadingScreen.classList.add('fade-out'), 1200);

    // Reveal scroll observer
    const revealElements = document.querySelectorAll('.reveal-item');
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) { entry.target.classList.add('visible'); entry.target.classList.remove('hidden-scroll'); }
            else { entry.target.classList.remove('visible'); entry.target.classList.add('hidden-scroll'); }
        });
    }, { threshold: 0.15, rootMargin: "0px 0px -50px 0px" });
    revealElements.forEach(el => revealObserver.observe(el));

    // Parallax
    const parallaxElements = document.querySelectorAll('.parallax-item');
    window.addEventListener('scroll', () => {
        parallaxElements.forEach(el => {
            const speed = el.getAttribute('data-speed') || 0.3;
            el.style.transform = `translateY(${window.scrollY * speed}px)`;
        });
    });

    // Load history
    renderHistory();

    // Preload voices for TTS
    if (window.speechSynthesis) {
        window.speechSynthesis.getVoices();
        window.speechSynthesis.addEventListener('voiceschanged', () => window.speechSynthesis.getVoices());
    }
});
